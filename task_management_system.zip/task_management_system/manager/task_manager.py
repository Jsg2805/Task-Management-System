from models.task import Task
from models.user import User
from utils.validators import validate_email
from utils.exceptions import UserAlreadyExistsError, TaskAlreadyExistsError, EntityNotFoundError

class TaskManager:
    """
    Manages users and tasks.
    """

    def __init__(self):
        """ 
        Initializes an instance of class task manager.
        Attributes:
        Takes task as dictionary.
        Takes users as dictionary.
        """
        self.tasks = {}
        self.users = {}

    def create_user(self, user_id, name, email):
        """
        Defines a function to create user.
        Args: 
        Takes user id.
        Takes Name.
        Takes Email.

        """
        if user_id in self.users:
            raise UserAlreadyExistsError(f"User ID '{user_id}' already exists.")
        validate_email(email)
        self.users[user_id] = User(user_id, name, email)
        """
        The entered user_id is checked in self.users.
        If you try to add a user of same USER ID, 
        An exception, UserAlreadyExistsError is raised
        If no exception is found, a new object is created into the dictionary 'users'.
        """

    def create_task(self, task_id, title, description, due_date, priority="Medium"):
        """
        Defines a function to create task.
        Args:
        Takes task_id.
        Takes title.
        Takes description.
        Takes due date.
        Priority is set to "Medium" by default.
        """
        if task_id in self.tasks:
            raise TaskAlreadyExistsError(f"Task ID '{task_id}' already exists.")
        
        self.tasks[task_id] = Task(task_id, title, description, due_date, priority)
        
    """
        The entered task.id is checked in tasks.
        If a task of same Task ID is found, TaskAlreadyExistsError exception is raised.
        If not a new object is created in the 'task' dictionary.

        """

    def delete_task(self, task_id):
        """
        A function to delete tasks is created.
        Args:
        Takes in task_id. 

        """
        if task_id not in self.tasks:
            raise EntityNotFoundError(f"Task ID '{task_id}' not found.")
        task = self.tasks[task_id]
        """
        If task_id is not in the tasks dictionary,
        An exception EntityNotFoundError is raised
        
        """
    
        if task.assigned_to:
            task.assigned_to.remove_task(task_id)
        del self.tasks[task_id]


    def get_task(self, task_id):
        return self.tasks.get(task_id)
    """
    Defines a function get_task
    Args:
    Taks id
    Return:
    Returns the corresponding task from the tasks dictionary
    
    """

    def list_all_tasks(self):
    
        return list(self.tasks.values())
    """
    Defines a task to return all the task from the tasks dictionary.
    Return:
    Returns all the task in the tasks dictionary
    """

    def list_tasks_by_user(self, user_id):
        user = self.users.get(user_id)
        return user.task_list if user else []
    """
    Defines a function to list tasks by users
    Args:
    Takes user_id
    Return:
    Returns the task according to the user id.

    """

    def list_tasks_by_status(self, status):
        return [task for task in self.tasks.values() if task.status == status]
    """
    Defines a function to list tasks by status
    Args:
    Takes status
    Return:
    Runs a loop which iterates through the tasks dictionary and returns their status.

    """

    def assign_task_to_user(self, task_id, user_id):
        task = self.tasks.get(task_id)
        user = self.users.get(user_id)
        """
        Defines a function to assign task to the user
        Args:
        Takes task_id.
        Takes user_id.

        """
        if not task:
            raise EntityNotFoundError(f"Task ID '{task_id}' not found.")
        if not user:
            raise EntityNotFoundError(f"User ID '{user_id}' not found.")
        task.assign_to(user)
        user.add_task(task)
        """
        If the entered task_id or user_id is not found, an exception EntityNotFoundError is raise.
        Else, Task is assigned to the user or can be vice versa.
      
        """
